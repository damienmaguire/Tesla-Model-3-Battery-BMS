The following files were generated for 'sign_core' in directory
C:\Users\damo\Desktop\Sig_gen_rev2\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * sign_core.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * sign_core.cdc
   * sign_core.constraints/sign_core.ucf
   * sign_core.constraints/sign_core.xdc
   * sign_core.ncf
   * sign_core.ngc
   * sign_core.ucf
   * sign_core.v
   * sign_core.veo
   * sign_core.xdc
   * sign_core_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * sign_core.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * sign_core.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * sign_core.gise
   * sign_core.xise

Deliver Readme:
   Readme file for the IP.

   * sign_core_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * sign_core_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

